// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xaccumulate_accel.h"

extern XAccumulate_accel_Config XAccumulate_accel_ConfigTable[];

XAccumulate_accel_Config *XAccumulate_accel_LookupConfig(u16 DeviceId) {
	XAccumulate_accel_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XACCUMULATE_ACCEL_NUM_INSTANCES; Index++) {
		if (XAccumulate_accel_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XAccumulate_accel_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XAccumulate_accel_Initialize(XAccumulate_accel *InstancePtr, u16 DeviceId) {
	XAccumulate_accel_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XAccumulate_accel_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XAccumulate_accel_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

